
import processing.core.*; 
import processing.data.*; 
import processing.event.*;
//import org.jdom2.Attribute;

import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JPanel;
import java.awt.image.BufferedImage;
import java.awt.Toolkit;
import java.awt.Dimension;

/*import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; */

public class OverLAY extends PApplet {

/** to be set by parent script **/
int wdth, heght;
float scle=1.0f;
String dirToLU="";
boolean zipMode=true;
boolean previewMode=false;
static String zipName;

/** global variables **/
int fontsize = 24;
int minWdth=300;
int W;
int H;
int D; 
//int x=0,y=0;
int c;
int mag_size=20;
int init_mag_size;
int magnifiedFrame=-1;
int magn=2;
int f=0;
int noL;
int f_Rate=30;
int fcCounter=0;
int channels=1;
int tChCalc=0;
int chTS=0;
int[] scrbPos=new int[4];
int done_strt=0;
int done_stp=0;
double zoom=1.0f;
int mx,my, mouseScroll;
int effectiveW, effectiveH;
int chbtOff=8;
float initScle, maxScle;
//int mouseScroll=0;
//boolean isExplorer=(navigator.appName == "Microsoft Internet Explorer");
//String[] imn=loadStrings("img.txt");
PImage[][] img;
boolean[][] calculated;
boolean[] requested;
boolean[] channeltoggler;
//int tbd=channels*D;
int reqCnt=0;
int maxReqItems;
int lastReqItem=0;
butoons[] btns;
scroolBar scrb;
fillBar FPSBar;
boolean mgnify;
boolean zoomable=true;
boolean resizeable;
boolean stp;
boolean inv;
boolean ovrly;
boolean mI=true;
boolean playable;
boolean imagesReady=false;
boolean imagesCalculated=false;
boolean mseOver=false;
boolean show_help=false;
XML xml;
//int maxPathLength=5;
String aW;
String ext=".jpg";
String helpString="SPACE - toggle play\nmouse scroll, LEFT/RIGHT arrow - step one frame\nUP/DOWN arrow - adjust the playback speed\n1-0 - toggle channels\nm - toggle magnifier\n o - toggle overlay\n h - toggle help";
overlys[] ols;
/** global colors**/
int sC=(0xff000022);
int fC=(0xff0099ff);
int afC=(0xffff9900);
int ofC=(0xffaaaaaa);
int button_bgColor=(0xff333333);

  static final int NOTYPE=-1;
  static final int PATH=0;
  static final int TXT=10;
  static final int TIME=11;
  static final int LNE=1;
  static final int ARRW=2;
  static final int PLYLINE=4;
  static final int PLYGON=5;
  static final int ELLPSE=6;
  static final int CHNNEL=12;
/**
* setup the script, the interface (setupButoons()) and load the overlay from 'overlay.xml' (loadXML())
**/
/*void setup(int _w, int _h, double _s, boolean _zm, String _xml, var _zip, boolean _pm) {
/ if (_w!=null){

    wdth=_w;
    heght=_h;
    scle=_s;
    initScle=_s;
    zipMode=_zm;
    previewMode=_pm;*/
public void setup(){
	surface.setResizable(true);
    initScle=scle;
    stp=false;
    inv=false;
    ovrly=true;
    textFont(createFont("Arial",fontsize));
    PFont fontA = createFont("Arial",12);
    textFont(fontA);
    mgnify=true;
    XML dimensions=xml.getChild(1);
    effectiveW=channels>1?wdth-22:wdth;
    effectiveH=heght-22;
    //channels=2;
    if (channels>1) chTS=channels;
    btns=new butoons[chbtOff+chTS];
    ext=dimensions.getString("ext");
    if (ext==null) ext=".jpg";
    if (match(ext,".")==null) ext="."+ext;
    maxReqItems=PApplet.parseInt(20/channels);
    channeltoggler=new boolean[channels];
    for (int k=0;k<channels;k++) channeltoggler[k]=true;
    //tbd=channels*D;
    noL=str(D).length()<3?3:str(D).length();
    if (xml.getChild(3).getName()=="controls"){
       XML controls=xml.getChild(3);
      f_Rate=PApplet.parseInt(controls.getInt("FPS"));
      if (f_Rate<5||f_Rate>60) f_Rate=25;
      playable=(controls.getInt("isPlayable")==1)?true:false;
      resizeable=(controls.getInt("isResizeable")==1)?true:false;
      stp=(controls.getInt("isPlaying")==1)?false:true;
      ovrly=(controls.getInt("overlaid")==1)?true:false;
      mgnify=(controls.getInt("magnifyable")==1)?true:false;
      mag_size=controls.getInt("mag_size");
      init_mag_size=mag_size;
      //println(controls.getInt("isPlaying"));
    }
    //println(D);
    int _D=(previewMode)?D+1:D;
    img=new PImage[channels+2][_D];
    calculated=new boolean[channels+2][_D];
    requested=new boolean[_D];
    f=(previewMode)?D:0;
    //self=Processing.getInstanceById("envideo_0");
    noStroke();
    background(0);
    fill(0); 
    frameRate(60);
    mouseScroll=0;
    setupButoons();
    loadXML();
    if (zipMode) getImgsfromZip();
    else getImgs();

}
public void setupButoons(){
  //play
 int[] vx={3,3,17};
 int[] vy={3,17,10};
 int offH=heght-19;
 btns[0]=new simpleButoon(1,offH,20,20,TRIANGLES,vx,vy); 
  //left
 int[] vx2={8,17,17,3,11,11};
 int[] vy2={10,3,17,10,3,17};
 btns[1]=new simpleButoon(1,offH,20,20,TRIANGLES,vx2,vy2); 
  //right
 int[] vx3={3,3,12,9,9,17};
 int[] vy3={3,17,10,3,17,10};
 btns[2]=new simpleButoon(22,offH,20,20,TRIANGLES,vx3,vy3); 
 btns[3]=new textButoon(wdth-108,offH,47,20,"MGNFY","magnify area under mouse"); 
 btns[4]=new textButoon(wdth-60,offH,47,20,"OVRLY", "toggle graphical overlay");
 btns[5]=new textButoon(wdth-162,offH,20,20," -", "zoom out"); 
 btns[6]=new textButoon(wdth-140,offH,20,20," +", "zoom in"); 
 btns[7]=new textButoon(wdth-12,offH,12,20,"?", "show help");
 btns[7].setColor=ofC;
 btns[3].setColor=(mgnify)?fC:ofC;
 btns[4].setColor=(ovrly)?fC:ofC;
 /*if (isExplorer||scle<1) {
    btns[5].setColor=butoons.offColor;
    btns[6].setColor=butoons.offColor;
 }*/
 if (channels>1) {
   for (int j=0;j<channels;j++) {
       btns[chbtOff+j]=new textButoon(wdth-21,1+j*21,20,20,(j+1)+"","channel "+(j+1));
   }
 }
 //println(f_Rate);
 FPSBar=new fillBar(22,offH,55,20,f_Rate,5,60);
 
 int strtPos=0;
 if (!playable) {
     btns[0].operational=false;
     FPSBar.operational=false;
     scrbPos[0]=44;scrbPos[1]=offH;scrbPos[2]=wdth-208;scrbPos[03]=20;strtPos=f;
 }
 else {
     btns[1].operational=false;
     btns[2].operational=false;
     scrbPos[0]=79;scrbPos[1]=offH;scrbPos[2]=wdth-246;scrbPos[03]=20;     
 }
 if (resizeable||!zoomable) {
   btns[5].operational=false;
     btns[6].operational=false;
   scrbPos[0]=80;scrbPos[1]=offH;scrbPos[2]=wdth-190;scrbPos[03]=20;
 }
 scrb=new scroolBar(scrbPos[0],scrbPos[1],scrbPos[2],scrbPos[3],0,D,strtPos,true,true); 
 if (stp) scrb.lop=!stp;
 //for (int i=0;i<btns.length;i++) println(i+"-"+btns[i].operational);
}
public void loadXML(){
   ols=new overlys[xml.getChildCount()-1];
   for (int i=0;i<xml.getChildCount()-1;i++){
      XML kid=xml.getChild(i+1);
      int t=PApplet.parseInt(kid.getInt("type"));
      //System.out.println(t+" type");
      //println(t+"a");
      switch (t) {
        case LNE:
          int s=PApplet.parseInt(kid.getInt("strt"));
          int l=PApplet.parseInt(kid.getInt("len"));
          int cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          int _x0=PApplet.parseInt(kid.getInt("x0"));
          int _x1=PApplet.parseInt(kid.getInt("x1"));
          int _y0=PApplet.parseInt(kid.getInt("y0"));
          int _y1=PApplet.parseInt(kid.getInt("y1"));
          ols[i]=new lne(s,l,cl,_x0,_y0,_x1,_y1);
        break;
    case ARRW:
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          _x0=PApplet.parseInt(kid.getInt("x0"));
          _x1=PApplet.parseInt(kid.getInt("x1"));
          _y0=PApplet.parseInt(kid.getInt("y0"));
          _y1=PApplet.parseInt(kid.getInt("y1"));
      int _hS=PApplet.parseInt(kid.getInt("head_size"));
      boolean _dH=(kid.getInt("double_head")==1)?true:false;
          ols[i]=new arrw(s,l,cl,_x0,_y0,_x1,_y1, _hS, _dH);
        break;
        case PATH:
          
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          int mdl=PApplet.parseInt(kid.getInt("mdl"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
        
          if (kid.getChildCount()>=l) {
            pth tmppath=new pth(s,l,mdl,cl);
            XML[] pts=kid.getChildren("p");
            if (pts.length!=l) pts=kid.getChildren("pt");
            for (int j=0;j<pts.length;j++){
               String[] p=pts[j].getContent().split(",");
               int[] pi=new int[2];
               for (int a=0;a<p.length;a++) pi[a]=PApplet.parseInt(p[a]);
               tmppath.loadPoint(j,pi[0],pi[1]); 
            }
            ols[i]=tmppath;
         
          }
          else ols[i]=new overlys();
          break;
        case PLYLINE:
    case PLYGON:
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          int n=PApplet.parseInt(kid.getInt("n"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          if (kid.getChildCount()>=n) {
        	  plyline tmppg;
            if (t==PLYLINE) { tmppg=new plyline(s,l,n,cl);}
            else {tmppg=new plygon(s,l,n,cl);}
            XML[] pts=kid.getChildren("p");
            if (pts.length!=n) pts=kid.getChildren("pt");
            for (int j=0;j<pts.length;j++){
               String[] p=pts[j].getContent().split(",");
               int[] pi=new int[2];
               for (int a=0;a<p.length;a++) pi[a]=PApplet.parseInt(p[a]);
               tmppg.loadPoint(j,pi[0],pi[1]); 
            }
            ols[i]=tmppg;
          }
          else ols[i]=new overlys();
          break;
    case ELLPSE:
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          int _x=PApplet.parseInt(kid.getInt("x"));
          int _y=PApplet.parseInt(kid.getInt("y"));
          int _w=PApplet.parseInt(kid.getInt("wdth"));
          int _h=PApplet.parseInt(kid.getInt("heght"));
          ols[i]=new ellpse(s,l,cl,_x+_w/2,_y+_h/2,_w,_h);
          //System.out.println(s+","+l+"-"+kid.getChildCount());
          break;
    case TXT:
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          _x=PApplet.parseInt(kid.getInt("x"));
          _y=PApplet.parseInt(kid.getInt("y"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          String value=kid.getContent();
          ols[i]=new txt(s,l,cl,_x,_y,value);
          break;
        case TIME:
           s=PApplet.parseInt(kid.getInt("strt"));
           l=PApplet.parseInt(kid.getInt("len"));
           _x=PApplet.parseInt(kid.getInt("x"));
           _y=PApplet.parseInt(kid.getInt("y"));
           cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          String u=kid.getString("unit");
          float inc=kid.getFloat("inc");
          float init=PApplet.parseFloat(kid.getContent());
          ols[i]=new tme(s,l,cl,_x,_y,init,inc,u);
          break;
    case CHNNEL:
          int c=PApplet.parseInt(kid.getInt("channel_no"));
          s=PApplet.parseInt(kid.getInt("strt"));
          l=PApplet.parseInt(kid.getInt("len"));
          _x=PApplet.parseInt(kid.getInt("x"));
           _y=PApplet.parseInt(kid.getInt("y"));
          cl=PApplet.parseInt(kid.getInt("clor"));
          cl=color((cl>>16&0xff),(cl>>8&0xff),(cl&0xff));
          u=kid.getContent();
      if (channels>1 && c>0 && c<=channels) {
        btns[chbtOff+c-1].setTootlTip(u);
        ols[i]=new txt(s,l,cl,_x,_y,u);
      }
      break;
        default:
          ols[i]=new overlys();
        break;
      }
   } 
 
}
/** end setup **/

/**
* main draw() function, this does the stuff
**/ 
public void draw() { 
     //println("f:"+f);
    mx=PApplet.parseInt(mouseX);//int((mouseX+dx)/zoom);
    my=PApplet.parseInt(mouseY);//(mouseY+dy)/zoom);

    scale(scle);
  fill(0);
  rect(0,0,wdth,heght);
 
    if (calculated[chTS][f]){
      /*if (resizeable) {      
        wdth=(int)(scle*img[chTS][f].width)+20;
        heght=(int)(scle*img[chTS][f].width)+20;
        //document.getElementById('content').style.width=(wdth)+'px';
        setupButoons();
        //self.size(wdth, heght);
        scale(scle);
      }*/
      image(img[chTS][f], 0, 0); 
      if (!imagesReady) {
        text("loading ",effectiveW/2-40,effectiveH/2);
        checkImages();
        /*int k=0;
        while (k<D&&calculated[chTS][k]) k++;
        done_stp=k-1;
        if (k>=D) {
          imagesReady=true;
          done_stp=k;
        }
        else{
          if (!calculated[channels-1][k]) preloadImages(k);
          if (channels>1&&calculated[channels-1][k]&&!calculated[chTS][k]) calculateImages(k);
        }*/
      }
      if (keyPressed){
        //println("'"+key+"' "+keyCode);
        if (key=='i')inv=!inv;
        if (keyCode==UP) {FPSBar.adjustValue(1);setFRate(++f_Rate);}
        if (keyCode==DOWN) {FPSBar.adjustValue(-1);setFRate(--f_Rate);}
        if (stp&&keyCode==LEFT) mouseScroll=-1;
        if (stp&&keyCode==RIGHT) mouseScroll=1;
        if (key==32&&playable) {  scrb.lop=!scrb.lop; 
              stp=!stp;
              f=scrb.pos;}
        int kk=key-49;
        if (kk>=0&&kk<channels) toggleChannel(kk+chbtOff);
        if (key=='o'||key=='O') buttonClicked(4);
        if (key=='m'||key=='M') buttonClicked(3);
        if (key=='h'||key=='H') buttonClicked(7);
        if (key=='-') buttonClicked(5);
        if (key=='+') buttonClicked(6);
        keyPressed=false;
      }
           
      pushStyle();
      if (ovrly&&!show_help) overly();
      popStyle();
      if (mgnify&&!show_help) Magnify();
      if (playable&&imagesReady&&!stp) ply();
      else if (mI) {    
        if (mouseScroll%1!=0) mouseScroll=0;
        f+=mouseScroll;
        
        if (f<0) f=0;
        else if (f>=D) f=D-1;
        scrb.setPos(mouseScroll);
        mouseScroll=0;
      }

    }
    else {
    	checkImages();
     /* if (!calculated[channels-1][f]) preloadImages(f);
      if (channels>1&&calculated[channels-1][f]&&!calculated[chTS][f]) calculateImages(f);*/
    }
    
    
   if (show_help) showHelp();
   scale(1.0f/scle);
   drawButoonBar();
} 
public void drawButoonBar(){
    
    pushStyle();
    fill(sC);
    noStroke();
    if (channels>1) rect(wdth-22,0,22,heght);
    rect(0,heght-22,wdth,22);
    noStroke();
    fill(button_bgColor);
    rect(scrbPos[0]+PApplet.parseInt(scrbPos[2]*done_strt/D),scrbPos[1],PApplet.parseInt(scrbPos[2]*done_stp/D),scrbPos[3]);
    popStyle();
    for (int i=0;i<btns.length;i++) {
       if (mI&&btns[i].museOver()) btns[i].fillColor=afC;
       else btns[i].fillColor=btns[i].setColor;
       if (btns[i].operational) btns[i].draw();
       if (btns[i].mouseClick()) buttonClicked(i);
    }
    if (scrb.mouseClick()) {
      scrb.drag();
      f=scrb.pos;
    }
    scrb.draw();
    if (FPSBar.mouseClick()) {
      FPSBar.setValueByClick();
      setFRate(FPSBar.value);
    }
   if (FPSBar.museOver()) {
     //println(mouseScroll+"-"+(f_Rate));
       FPSBar.adjustValue(mouseScroll);
       setFRate(f_Rate+mouseScroll);
       mouseScroll=0;
    }
    
    if (FPSBar.operational) FPSBar.draw();
    
    /*pushStyle();
    fill(fC);
    text(fRate+" FPS",66,225);
    popStyle();*/
}
public void showHelp(){
  pushStyle();
  fill(0xffff9900,180);
  rect (2,2,296,146);
  fill (0xffffffff,255);
  text (helpString,4,6,292,143);
  popStyle();
}

/** end main **/

/**
* preload and (re)calulate the images from a directory or from a zip file
**/
public void checkImages(){
	done_stp=0;
	int i=0,j=0;
	try{
	for (i=0;i<D;i++){
		boolean allChannels=true;
		for (j=0;j<channels;j++){
			if (img[j][i]!=null&&img[j][i].width!=0) calculated[j][i]=true;
			allChannels&=calculated[j][i];	
		}
		if (allChannels) {
			if (channels>1) calculateImages(i);
			done_stp++;
		}
	}
	}
	catch (NullPointerException ne){
		System.out.println(i+","+j+"-"+D+","+img[j][i]+","+calculated.length);
		System.exit(1);
	}
	//System.out.println(done_stp+","+D);
	if (done_stp>=D) imagesReady=true;
}

public void calculateImages( int frme){
     //noLoop();
     //if (calculated[channels-1][frme]){
      text("computing ",W/2-40,H/2+20);
      if (chTS>=channels) img[chTS][frme]=createImage(img[0][frme].width,img[0][frme].height,RGB);  
      for (int j=0;j<channels;j++){
        //alert(img[j][frme].width);
         if (channeltoggler[j]) img[chTS][frme]=addChannel(img[j][frme],img[chTS][frme]);
      }
    
     calculated[chTS][frme]=true;
     
   //}
   //frameRate(60); 
   //loop();
}

public PImage addChannel(PImage src, PImage dest){
    dest.loadPixels();
    src.loadPixels();
    int w=dest.width;
    int h=dest.height; 
    int off=0, dpx=0,spx=0, idx=0;
    if (w==src.width&&h==src.height){
      for (int i=0;i<h;i++){
        for (int j=0;j<w;j++){
          idx = (off + j);
          dpx=dest.pixels[idx];
          spx=src.pixels[idx];
          dest.pixels[idx]=(Math.min((dpx>>16&255)+(spx>>16&255),255)<<16)+(Math.min((dpx>>8&255)+(spx>>8&255),255)<<8)+(Math.min((dpx>>0&255)+(spx>>0&255),255)<<0);
          //sum+=(dpx>>16&0xff)+(spx>>16&0xff);
          //else destPixels[idx+c]=srcPixels[idx+c];
        }
        off+=w;
      }
    }
    //println(sum);
    dest.updatePixels();
    return dest;
}
private void getImgs(){
	for (int i=0;i<D;i++){
		for (int j=0;j<channels;j++){
			img[j][i]=requestImage(getName(j,i));
		}
	}
}
private void getImgsfromZip(){
	try{
		FileInputStream zipFile=new FileInputStream(zipName);
		ZipInputStream zip = new ZipInputStream (zipFile);
		ZipEntry ze = zip.getNextEntry();
		while(ze!=null){
			String fn=ze.getName();
			if (fn.contains(ext)){
				int ch=fn.charAt(0)-97;
				int q=Integer.parseInt(fn.substring(1, fn.indexOf(ext)));
				if (ch<channels&&q>=0&&q<D){
					BufferedImage bi=ImageIO.read(zip);
					img[ch][q]=new PImage(bi);
				}
				
			}
			ze = zip.getNextEntry();
		}
		zip.close();
		zipFile.close();
		
	}
	catch (FileNotFoundException fne) {
		JOptionPane.showMessageDialog(frame,
				"The movie file appears to be missing, OverLAY shuts down");		
		 System.exit(1);
	} 

	catch (IOException ioe) {
		JOptionPane.showMessageDialog(frame,
				"The movie file appears to be corrupt, OverLAY shuts down");
		 System.exit(1);
	}
	catch (Throwable t){
		JOptionPane.showMessageDialog(frame,
			    "An undefined error occured, OverLAY shuts down");
		 System.exit(1);
	}
}
private void getImgfromZip(int ch, int q){
	String iname=getName(ch,q);
	try{
		FileInputStream zipFile=new FileInputStream(zipName);
		ZipInputStream zip = new ZipInputStream (zipFile);
		ZipEntry ze = zip.getNextEntry();
		while (ze!=null&&!ze.getName().equals(iname)) {
		ze = zip.getNextEntry();}
		BufferedImage bi=ImageIO.read(zip);
		img[ch][q]=new PImage(bi);
		zip.close();
		zipFile.close();
		
	}
	catch (FileNotFoundException fne) {
		JOptionPane.showMessageDialog(frame,
				"The movie file appears to be missing, OverLAY shuts down");		
		 System.exit(1);
	} 

	catch (IOException ioe) {
		JOptionPane.showMessageDialog(frame,
				"The movie file appears to be corrupt, OverLAY shuts down");
		 System.exit(1);
	}
	catch (Throwable t){
		JOptionPane.showMessageDialog(frame,
			    "An undefined error occured, OverLAY shuts down");
		 System.exit(1);
	}
}
public String getName(int ch, int q){
   String ret=str(PApplet.parseChar(97 + ch));  
   for (int i=0;i<noL-str(q).length();i++) ret+="0";
   ret+=str(q)+ext;
   //alert(ret);
  if (zipMode) return ret;
  else return dirToLU+ret;
}

/** end preload**/

/**
* controls
**/
public void buttonClicked(int i){
 switch(i){
  case 0:
   scrb.lop=!scrb.lop; 
   stp=!stp;
   f=scrb.pos;
  break;
  case 1:
    scrb.setPos(-1);
    f=scrb.pos;
   
  break;
  case 2:
    scrb.setPos(1);
    f=scrb.pos;
    
  break;
  case 3:
    mgnify=!mgnify;
    btns[i].setColor=mgnify?fC:ofC;
  break;
  case 4:
    ovrly=!ovrly;
    btns[i].setColor=ovrly?fC:ofC;
    break;
  case 5:
	//mgnify=false;
  scle=(scle*0.75f<initScle)?initScle:(float)round(scle*7.5f)/10; 
  doZoom();
    break;
  case 6:
	  mgnify=false;
	  btns[3].setColor=fC;
  scle=(scle*1.25f>maxScle)?maxScle:(float)round(scle*12.5f)/10;
  doZoom();
    break;
  case 7:
  show_help=!show_help;
  break;
  case 8:
  case 9:
  case 10:
  case 11:
  case 12:
  case 13:
  case 14:
  case 15:
  case 16:
  case 17:
    toggleChannel(i);
   
  break;
  default:
  break;
 }
  mousePressed=false;
}
void doZoom(){ 
    wdth=round(scle*img[chTS][f].width)+22;
    heght=round(scle*img[chTS][f].height)+22;
    mag_size=(int)(init_mag_size*scle);
    if (wdth<minWdth) wdth=minWdth;
    effectiveW=channels>1?wdth-22:wdth;
    effectiveH=heght-22;
    surface.setSize(wdth,heght);
    setupButoons();
    //if (btns[3].setColor==fC) mgnify=true;
    
}
public void toggleChannel(int i){
   // println(i);
   if (mouseButton==RIGHT){
     if (chTS==channels) {
       for (int k=0;k<channels;k++) channeltoggler[k]= false; 
       channeltoggler[i-chbtOff]=true;
       chTS=i-chbtOff;
     }
     else {
        for (int k=0;k<channels;k++) channeltoggler[k]= true; 
        chTS=channels;
     }  
     //for (int k=0;k<channels;k++)  btns[k+chbtOff].setColor=channeltoggler[k]?butoons.defaultColor:butoons.offColor;
   }
   else {
    channeltoggler[i-chbtOff]=!channeltoggler[i-chbtOff];
    int c=0;
    int c2=0;
    for (int j=0;j<channels;j++) {
       if (channeltoggler[j]) {
          chTS=j;
          c++;
          c2+=1<<j;
          
       } 
    }
    
    if (c!=0&&c!=1&&c!=channels){
      chTS=channels+1; 
     if (c2!=tChCalc){
       for (int k=0;k<D;k++) calculated[chTS][k]=false;
       imagesReady=false;
       tChCalc=c2;
     }
    
    }
    if (c==channels) {
      chTS=channels;
    }
    if (c==0) {
      channeltoggler[i-chbtOff]=!channeltoggler[i-chbtOff];
    }
   // println(channels+":"+c+"-"+chTS);
    btns[i].setColor=channeltoggler[i-chbtOff]?fC:ofC;
   }
  
}
public void ply(){
    //img=loadImage(imn[f]);
     if (fcCounter/60>=1) {
         f++;
         scrb.setPos(1);
         fcCounter=fcCounter%60;
     }
     fcCounter+=f_Rate; 
     if (f>=D) f=0;
    
}
public void setFRate(int fr){
  f_Rate=fr;
  if (f_Rate>60) f_Rate=60;
  else if (f_Rate<5) f_Rate=5;
  //frameRate(fRate);
}
public void overly(){
   for (int i=0;i<ols.length;i++){
     //println(ols[i].type);
    // println(overlys.PATH);
    if (f>=ols[i].strt&&f<=ols[i].ed){
      
      ols[i].draw(f);
      
     }
   }
   
}
public void Magnify() {
    int x=mx;
    int y=my;
  if (x>0&&x<effectiveW && y>0&&y<effectiveH && mI) {
    //img[chTS][f].magnify(x,y,mag_size,magn);
    //magnifiedFrame=f;
  
    loadPixels();
    int d=2*mag_size+1;
    int[] tc=new int[d*d];
    if (x>0&&x<effectiveW && y>0&&y<effectiveH && mI){
        for (int i=-mag_size;i<mag_size;i++){
        for (int j=-mag_size;j<mag_size;j++){
           if (x+j*magn>0&&y+i*magn>0&&x+j*magn<wdth&&y+i*magn<heght) {
              //println(x+j+(y+i)*wdth);
              c=pixels[x+j+(y+i)*wdth];
              //println(c+",");
              if (inv) c=invrt(c);
              tc[(i+mag_size)*d+j+mag_size]=c;
           }
        }
        }
        for (int i=-mag_size;i<mag_size;i++){
          for (int j=-mag_size;j<mag_size;j++){
           if (x+j*magn>0&&y+i*magn>0&&x+j*magn<wdth-1&&y+i*magn<heght-1) {
              for (int a=0;a<2;a++){
                  for (int b=0; b<2;b++){
                    pixels[x+j*magn+b+(y+i*magn+a)*wdth]=tc[(i+mag_size)*d+j+mag_size];
                  }
              }
             //rect(x+j*mag,y+i*mag,mag,mag);
           }
        }
      }
    }
    updatePixels();
  }
}
public int invrt(int c){
   //int a=0xff;
   int r=0xff-(c>>16&0xff); 
   int g=0xff-(c>>8&0xff); 
   int b=0xff-(c&0xff); 
   return color(r,g,b);
}

public void mouseWheel(MouseEvent event) {
  mouseScroll = (int)event.getCount();
  //println(e);
}
/*void mouseClicked(){
  //if (mouseButton==LEFT) stp=!stp;
  if (mouseButton==RIGHT) ovrly=!ovrly;
  
}*/
/** end controls **/

/**
* Interface objects
* abstract class 'butoons' defines appearance and basic operations
* such as mouse over and mouse click
* each children must have their own draw method 
**/
class butoons {
  //static color frmeColor=0xff888888;
  int bgColor=button_bgColor;
  /*static color strokeColor=sC;*/
  int defaultColor=fC;
  int alternativeColor=afC;
  int offColor=ofC;
  int x,y;
  int w,h;
  public int fillColor;
  public int setColor;
  boolean operational, rightAlign, bottomAlign;
  
  butoons(int a, int b, int c, int d){
      x=a;
      y=b;
      w=c;
      h=d; 
    rightAlign=(wdth-x<50);
    bottomAlign=(heght-y<30);
      fillColor=fC;
      setColor=fC;
      operational=true;
  }
  public void drawFrame(){
     noStroke();
     fill(bgColor);
     rect(x,y,w,h);
  }
   public boolean museOver(){
     return (operational&&abs(mx-x-w/2)<w/2)&& (abs(my-y-h/2)<h/2) ;
  }
  public boolean mouseClick(){
     return operational&&this.museOver()&&mousePressed; 
  }
  public void setTootlTip(String _tT){}
  public void draw(){}
}
class textButoon extends butoons{
  String label, tT;
 // PFont lFont=new Font("Arial");
  int fontSize=12;
  int tTx,tTy,tTw,tTh;
  textButoon(int a, int b, int c, int d, String l, String _tT){
    super(a,b,c,d);
    label=l;
    setTootlTip(_tT);
  }
  public void draw(){
    pushStyle();
    drawFrame();
    fill(fillColor);
    text(label,x+3,y+fontSize+2);
    if (museOver()) toolTip();
    popStyle();
  }
  public void setTootlTip(String _tT){
    tT=_tT;
    int tTl=tT.length();
    tTw=(tTl*fontSize<wdth/4)?tTl*fontSize:wdth/4;
    tTh=(tTw<wdth/4)?fontSize:ceil(tTl/(wdth/(4*fontSize)))*fontSize;
    if (bottomAlign) {
      tTy=y-tTh;
      if (x+tTw-(tTw-w)/2>wdth) tTx=x-tTw-2;
        else tTx=x-(tTw-w)/2-2;
      }
    else if (rightAlign) {tTy=y+3;tTx=x-tTw-2;}
    else {tTy=y+3;tTx=x+30;}
  }
  public void toolTip(){
    if (rightAlign)  textAlign(RIGHT);
      else textAlign(CENTER, BOTTOM);
    text(tT,tTx,tTy,tTw,tTh);
  }
}
class simpleButoon extends butoons{
  int mode;
  int noV;
  int[] verticesX;
  int[] verticesY;
  int strokeColor;


  simpleButoon(int a, int b, int c, int d, int m, int[] vx, int vy[]){
    super(a,b,c,d);
    if (vx.length==vy.length){
      x=a;
      y=b;
      w=c;
      h=d;
      mode=m;
      noV=vx.length;
       verticesX=new int[noV];
       verticesY=new int[noV];
       for (int i=0;i<vx.length;i++) verticesX[i]=vx[i]+a;
       for (int i=0;i<vy.length;i++) verticesY[i]=vy[i]+b;
       fillColor=fC;
       setColor=fC;
       strokeColor=sC;
       operational=true;
    }
    else operational=false;
  }
  public void draw(){
     pushStyle();
     drawFrame();
     stroke(strokeColor);
     fill(fillColor); 
     beginShape(mode);
     for (int i=0;i<verticesX.length;i++){ 
       vertex(verticesX[i],verticesY[i]);
     }
     endShape();
     popStyle();
    }
 
}
class scroolBar extends butoons{
   int _mn, _mx, range;
   int bw;
   int pos;
   float step;
   public boolean lop;  
   boolean vertical;
   boolean transparent;
   scroolBar(int a, int b, int c, int d, int _min, int _max, int _ps, boolean _lop, boolean _t){
        super(a,b,c,d);
        _mn=_min;
        _mx=_max;
        range=_mx-_mn;
        pos=_ps;
        if (h>w) {
          vertical=true;
          step=(float)range/h;
        }
        else {
          vertical=false;
          step=(float)range/w;
        }
        bw=PApplet.parseInt(round((float)(1/step)));
        if (bw<1) bw=1;
        lop=_lop;
        transparent=_t;
        fillColor=fC;
      
         
   }
   public void toolTip(){
       //fill(textColor);
       if (vertical){
         int tpos=(int)((y+h-my)*step)+1;
         text(tpos+"",x-20,my+2);
       }
       else{
         int tpos=(int)((mx-x)*step)+1;
         text(tpos+"",mx+2,y-3);
       }
   }
   public void draw(){
      pushStyle();
      if (!transparent) drawFrame();
      fill(fillColor);
      if (vertical) rect(x,y+h-(int)(pos/step),w,bw);
      else rect(x+(int)((float)pos/step),y,bw,h);
      if (museOver()) toolTip();
      popStyle();      
   }
   public void setPos(int increment){
      pos+=increment;
      if (pos<0) {
         if (lop) pos=range-1;
         else pos=0;
      }
      if (pos>=range) {
         if (lop) pos=0;
         else pos=range-1;
      }
      
   }
   public void drag(){
     if (vertical) pos=(int)((y+h-my)*step);
     else pos=(int)((mx-x)*step);
     //println(pos);
   }
}
class fillBar extends butoons{
   int _mn, _mx, range;
   int bw;
   int value;
   double step;
   boolean vertical;
   fillBar(int a, int b, int c, int d, int initValue, int _min, int _max){
       super(a,b,c,d);
       _mn=_min;
       _mx=_max;
       range=_mx-_mn;
      if (abs(initValue-_mn)<=abs(range)){
         x=a;
         y=b;
         w=c;
         h=d; 
         this.value=initValue;
         if (h>w){
           vertical=true;
           step=range/h;
         }
        else{
           vertical=false;
           step=range/w;
         }
         bw=(int)((value-_mn)/step);

         fillColor=fC;
         setColor=fillColor;
         operational=true;
       } 
       else{ operational=false;
     }
   }
   public void toolTip(){
      if (vertical) {
        text((value)+"",x-20,y+h-bw+2);
      }
      else {
 
        text((value)+"",x+bw+2,y-2);
      }
   }
   public void draw(){
     //println("a");
     //println(bw+"="+value+"-"+mn+"*"+step);
      pushStyle();
      drawFrame();
      fill(fillColor);
      
      if (vertical) rect(x,y+h-bw,w,bw);
      else rect(x,y,bw,h);
      if (museOver()) toolTip();
      popStyle();     
   }
   public void adjustValue(int increment){
     if (increment%1!=0) increment=0;
      value+=increment;
      check(); 
   }
   public void setValue(int nValue){
      value=nValue;
      check(); 
   }
   public void setValueByClick(){
      if (vertical) value=_mn+(int)((y+h-my)*step);
      else value=_mn+(int)((mx-x)*step);
      check(); 
   }
   public void check(){
      if (value<_mn) value=_mn;
      else if (value>_mx) value=_mx;
      bw=(int)((value-_mn)/step);
   }
}
/** end interface objects**/

/**
* Overlay objects, childred of abstract class 'overlys'
* each children must have their own draw method 
**/
class overlys{
  int strt;
  int ln;
  int ed;
  int type;
  int clr;
  overlys(){
    type=NOTYPE;
    strt=0;
    ln=0;
    ed=0;
    clr=color(0,0,0);
  }
  overlys(int s, int l, int c){
    
    strt=s;
    ln=l;
    ed=strt+ln-1;
    clr=c;
  }
  public void draw(int _f){
  }
  //public void loadPoint(int p, int x, int y){}
}
class lne extends overlys{
  int x0,y0,x1,y1;
  lne(int s, int l, int c, int _x0, int _y0, int _x1, int _y1){
       strt=s;
       ln=l;
       ed=strt+ln-1;
       clr=c;
       x0=_x0;
       y0=_y0;
       x1=_x1;
       y1=_y1;
       type=LNE;  
  }
  public void draw(int _f){
    stroke(clr,255);
    strokeWeight(1);
    line(x0,y0,x1,y1);
  }
}
class arrw extends lne{
  int headSize;
  int[] arrowCoords;
  boolean doubleHeads;
  float arrwAngle=PI/6;
  arrw(int s, int l, int c, int _x0, int _y0, int _x1, int _y1, int _hS, boolean _dH){
    super(s,l,c,_x0,_y0,_x1,_y1);
    headSize=_hS;
    doubleHeads=_dH;
    if (doubleHeads) arrowCoords=new int[12];
    else arrowCoords=new int[6];
    int lngth=(int)(sqrt(pow(x1-x0,2)+pow(y1-y0,2)));
    float angl=-asin((float)(y0-y1)/(float)lngth);
    //alert(angl);
    arrowCoords[0]=x1;arrowCoords[1]=y1;
    if (x1>=x0) {arrowCoords[2]=(int)(x1-cos(angl+arrwAngle)*headSize);arrowCoords[3]=(int)(y1-sin(angl+arrwAngle)*headSize);}
    else {arrowCoords[2]=(int)(x1+cos(angl+arrwAngle)*headSize);arrowCoords[3]=(int)(y1-sin(angl+arrwAngle)*headSize);}
    if (x1<x0) {arrowCoords[4]=(int)(x1+cos(angl-arrwAngle)*headSize);arrowCoords[5]=(int)(y1-sin(angl-arrwAngle)*headSize);}
    else {arrowCoords[4]=(int)(x1-cos(angl-arrwAngle)*headSize);arrowCoords[5]=(int)(y1-sin(angl-arrwAngle)*headSize);}
    if (doubleHeads){
      angl=-1*angl;
      arrowCoords[6]=x0;arrowCoords[7]=y0;
      if (x0>=x1) {arrowCoords[8]=(int)(x0-cos(angl+arrwAngle)*headSize);arrowCoords[9]=(int)(y0-sin(angl+arrwAngle)*headSize);}
      else {arrowCoords[8]=(int)(x0+cos(angl+arrwAngle)*headSize);arrowCoords[9]=(int)(y0-sin(angl+arrwAngle)*headSize);}
      if (x0<x1) {arrowCoords[10]=(int)(x0+cos(angl-arrwAngle)*headSize);arrowCoords[11]=(int)(y0-sin(angl-arrwAngle)*headSize);}
      else {arrowCoords[10]=(int)(x0-cos(angl-arrwAngle)*headSize);arrowCoords[11]=(int)(y0-sin(angl-arrwAngle)*headSize);}
    }
    type=ARRW;
  }
  public void draw(int _f){
    
    stroke(clr,255);
    strokeWeight(1);
    //beginShape(LINES);
    line(x0,y0,x1,y1);
    pushStyle();
    fill(clr);
    triangle(arrowCoords[0],arrowCoords[1],arrowCoords[2],arrowCoords[3],arrowCoords[4],arrowCoords[5]);
    if (doubleHeads) triangle(arrowCoords[6],arrowCoords[7],arrowCoords[8],arrowCoords[9],arrowCoords[10],arrowCoords[11]);
    popStyle();
    //line(arrowCoords[0],arrowCoords[1],arrowCoords[4],arrowCoords[5]);
    //endShape();
  }
}
class ellpse extends overlys{
  int x,y,w,h;
  ellpse(int s, int l, int c, int _x, int _y, int _w, int _h){
    strt=s;
    ln=l;
    ed=strt+ln-1;
    clr=c;
    x=_x;
    y=_y;
    w=_w;
    h=_h;
    type=ELLPSE; 
  }
  public void draw(int _f){
    noFill();
    stroke(clr,255);
    strokeWeight(1);
    ellipse(x,y,w,h);
  }
}
class plyline extends overlys{
  int[] xs;
  int[] ys;  
  int np;
  plyline (int s, int l, int n, int c){
     strt=s;
     ln=l;
     ed=strt+ln-1;
     clr=c;
     np=n;
     xs=new int[n];
     ys=new int[n]; 
     type=PLYLINE;  
  }  
  public void loadPoint(int p, int x, int y){
      if (p>=0&&p<np) {
        xs[p]=x;
        ys[p]=y;
      }
  }
  public void draw(int _f){
   noFill();
   stroke(clr,255);
   strokeWeight(1);
   beginShape();
   for (int i=0;i<np;i++){
      vertex(xs[i],ys[i]);
   } 
   if (this.type==PLYLINE) {endShape();}
   else endShape(CLOSE);
  }
}
class pth extends plyline{
  int maxDispLen;
  pth(int s, int l, int mdl, int c){
     super(s,l,l,c);
     maxDispLen=mdl;
     type=PATH; 
  }
  public void draw(int _f){
	  pushStyle();
   noFill();
   stroke(clr,255);
   strokeWeight(1);
   beginShape();
   for (int i=(_f-strt-maxDispLen<0)?0:(_f-strt-maxDispLen);i<=(_f-strt);i++){
      vertex(xs[i],ys[i]);
   } 
   endShape();
   popStyle();
}
}
class plygon extends plyline{
  plygon(int s, int l, int n, int c){
     super(s,l,n,c);
     type=PLYGON; 
  }
}
class txt extends overlys{
   String value;
   int x0,y0;
   txt(int s, int l, int c, int _x, int _y, String _value) {
       strt=s;
       ln=l;
       ed=strt+ln-1;
       clr=c;
       type=TXT;
       value=_value;
       x0=_x;
       y0=_y+10;
   }
   public void draw(int _f){
      pushStyle();
      fill(clr);
      text (value,x0,y0);
      popStyle();
  } 
}
class tme extends overlys{
   float init;
   float increment;
   float actual;
   int decimals;
   int x0,y0;
   String unit;
   String actTime;
   boolean unitChange;
   tme(int s, int l, int c, int _x,int _y, float _init, float _increment, String _unit){
       strt=s;
       ln=l;
       ed=strt+ln-1;
       clr=c;
       type=TIME;
       x0=_x;
       y0=_y+10;
       init=_init;
       increment=_increment;
       decimals=getDecimals(increment);
       actual=init;
       unit=_unit;
       if (ln*increment>60&&(unit=="s"||unit=="sec"||unit=="min")) unitChange=true;
   }
   public int getDecimals(float fl){
      int dec=0;  
      while (fl%10!=0) {
          fl*=10;
          dec++;
      }
      return --dec; 
   }
   public void setTimeString(){
      if (unitChange) actTime=nf(PApplet.parseInt(floor(actual/60)),2)+":"+nfs(actual%60,2,decimals)+" "+unit;
      else actTime=nfs(actual,2,decimals)+" "+unit;
   }
   public void setTme(int noInc){
      actual=init+PApplet.parseFloat(noInc)*increment;
      setTimeString();
   }
  public void draw(int _f){
      pushStyle();
      fill(clr);
      setTme(_f);
      text (actTime,x0,y0);
      popStyle();
  } 
}
	private void initOverLAY(){
		if (zipName==null){
			JFileChooser fc=new JFileChooser();
			FileNameExtensionFilter filter = new FileNameExtensionFilter(
		        "OverLAY formats", "zip", "xml","ovl");
			fc.setFileFilter(filter);
			int returnVal = fc.showOpenDialog(new JPanel());
			if(zipName!=null||returnVal == JFileChooser.APPROVE_OPTION) {
				zipName=fc.getSelectedFile().getPath();
				if (zipName.contains(".xml")) {
					zipMode=false;
					dirToLU=fc.	getCurrentDirectory().getPath()+"\\";
				}
			}
		}
		if(zipName!=null){
		    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		    double width = screenSize.getWidth()-80;
		    double height = screenSize.getHeight()-80;
			try{
				if (zipMode){
					FileInputStream zipFile=new FileInputStream(zipName);
					ZipInputStream zip = new ZipInputStream (zipFile);
					ZipEntry ze = zip.getNextEntry();
					while (ze!=null&&!ze.getName().equals("overlay.xml")) {ze = zip.getNextEntry();}
					int len=0;
					byte[] buffer=new byte[100];
					ByteArrayOutputStream bs=new ByteArrayOutputStream();
					while ((len=zip.read(buffer))>0){
						bs.write(buffer,0,len);
				
					}
					xml=parseXML(new String(bs.toByteArray()));
					zip.close();	
					zipFile.close();
				}
				else xml=loadXML(zipName);
			    XML dimensions=xml.getChild(1);
			    W=PApplet.parseInt(dimensions.getInt("width"));
			    H=PApplet.parseInt(dimensions.getInt("height"));
			    D=PApplet.parseInt(dimensions.getInt("depth"));
			    channels=PApplet.parseInt(dimensions.getInt("channels"));
			    wdth=(channels>1)?W+22:W;
			    if (wdth<minWdth) wdth=minWdth;
			    heght=H+22;
			    maxScle=(width/(float)wdth>height/(float)heght)?(float)height/heght:(float)width/wdth;
			    if (wdth>width) {
			    	scle=(float)width/(float)wdth;
			    	maxScle=scle;
			    	wdth=(int)width;
			    	heght=(int)(scle*heght);
			    }
			    if (heght>height) {
			    	scle=(float)height/(float)heght;
			    	maxScle=scle;
			    	heght=(int)height;
			    	wdth=(int)(scle*wdth);
			    }

			}
			catch (FileNotFoundException fne) {
				JOptionPane.showMessageDialog(frame,
						"The movie file appears to be missing, OverLAY shuts down");		
				 System.exit(1);
			} 
	
			catch (IOException ioe) {
				JOptionPane.showMessageDialog(frame,
						"The movie file appears to be corrupt, OverLAY shuts down");
				 System.exit(1);
			}
			catch (Throwable t){
				JOptionPane.showMessageDialog(frame,
					    "An undefined error occured, OverLAY shuts down");
				 System.exit(1);
			}
		}
		else  System.exit(1);
	}
	
  public void settings() {
	  initOverLAY();
	  size(wdth,heght);

	  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] {"OverLAY" };
    if (passedArgs != null) {
    	if (passedArgs.length>0) {
    		if (passedArgs[0].contains(".zip")||passedArgs[0].contains(".ovl")) zipName=passedArgs[0];
    	}
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
